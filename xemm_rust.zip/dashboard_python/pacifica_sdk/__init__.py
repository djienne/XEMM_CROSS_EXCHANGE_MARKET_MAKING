"""PACIFICA SDK package exposing REST and WS helpers."""
