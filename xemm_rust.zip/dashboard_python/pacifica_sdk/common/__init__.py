"""Common helpers shared across PACIFICA SDK modules."""
