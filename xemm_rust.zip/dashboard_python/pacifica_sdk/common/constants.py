# Mainnet
REST_URL = "https://api.pacifica.fi/api/v1"
WS_URL = "wss://ws.pacifica.fi/ws"

# Testnet
# REST_URL = "https://test-api.pacifica.fi/api/v1"
# WS_URL = "wss://test-ws.pacifica.fi/ws"
