pub mod opportunity;

pub use opportunity::{Opportunity, OpportunityEvaluator, OrderSide};
